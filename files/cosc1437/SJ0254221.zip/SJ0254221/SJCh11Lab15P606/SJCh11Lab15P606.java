/*
 *  Steven S. Johnson (0254221)
 *  COSC-1437-9467 (461331)
 *  Chapter 11 / Lab 15 / Page 606
 */

public class SJCh11Lab15P606 {

	public static void main(String[] args) {
		GuessFrame guessFrame = new GuessFrame();
		guessFrame.setDefaultCloseOperation(javax.swing.JFrame.EXIT_ON_CLOSE);
		guessFrame.setSize(480, 100);
		guessFrame.setVisible(true);
	}

}
