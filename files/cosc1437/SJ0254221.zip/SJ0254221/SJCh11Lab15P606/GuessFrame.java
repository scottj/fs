import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.FlowLayout;
import java.lang.Math;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import java.util.Random;

public class GuessFrame extends JFrame {
	ActionListener buttonHandler = new ButtonHandler();
	ActionListener playAgainHandler = new PlayAgainHandler();
	boolean firstGuess = true;
	int lastGuess;
	int randomNumber;
	int numberGuessed;
	JButton button1;
	JLabel label1;
	JLabel label2;
	JLabel label3;
	JLabel label4;
	JTextField numberInput;
	Random random;

	public GuessFrame() {
		super("Lab 11.15 - Guess the Number");

		random = new Random();
		randomNumber = 1 + random.nextInt(1000);

		setLayout(new FlowLayout());

		label1 = new JLabel("I have a number between 1 and 1000.");
		add(label1);

		label2 = new JLabel("Can you guess my number?");
		add(label2);

		label3 = new JLabel("Please enter your first guess.");
		add(label3);

		numberInput = new JTextField();
		numberInput.setColumns(5);
		numberInput.setHorizontalAlignment(SwingConstants.TRAILING);
		numberInput.addActionListener(new TextFieldHandler());
		add(numberInput);

		button1 = new JButton("Guess");
		button1.addActionListener(buttonHandler);
		add(button1);

		label4 = new JLabel(" "); // status updates will go here
		add(label4);

		getContentPane().setBackground(Color.white);
	}

	private class ButtonHandler implements ActionListener {
		public void actionPerformed(ActionEvent event) {
			numberGuessed = Integer.parseInt(numberInput.getText());
			if (!firstGuess) {
				if (Math.abs(numberGuessed - randomNumber) > Math.abs(lastGuess
						- randomNumber)) {
					// if guess is further from the number, turn background red
					getContentPane().setBackground(Color.red);
				} else {
					// if guess is closer or equal, turn background blue
					getContentPane().setBackground(Color.blue);
				}
			} else {
				firstGuess = false;
			}
			if (numberGuessed < randomNumber) {
				label4.setText("Too Low");
			} else if (numberGuessed > randomNumber) {
				label4.setText("Too High");
			} else { // handle the correct answer here
				numberInput.setEditable(false);
				label4.setText("Correct!");
				button1.setText("Play Again?");
				button1.removeActionListener(buttonHandler);
				button1.addActionListener(playAgainHandler);
			}
			lastGuess = numberGuessed;
		}
	}

	private class PlayAgainHandler implements ActionListener {
		// reset the state of everything back to the way it was before
		public void actionPerformed(ActionEvent event) {
			numberInput.setEditable(true);
			numberInput.setText("");
			label4.setText("");
			button1.setText("Guess");
			getContentPane().setBackground(Color.white);
			button1.removeActionListener(playAgainHandler);
			button1.addActionListener(buttonHandler);
			randomNumber = 1 + random.nextInt(1000);
			lastGuess = 0;
			firstGuess = true;
		}
	}

	private class TextFieldHandler implements ActionListener {
		// handle pressing of enter in numberInput field
		public void actionPerformed(ActionEvent event) {
			button1.doClick();
		}
	}
}
