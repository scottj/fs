/*
 *  Steven S. Johnson (0254221)
 *  COSC-1437-9467 (461331)
 *  Chapter 30 / Lab 3 / Page 1503
 */

import java.util.Scanner;

public class SJCh30Lab3Page1503 {
	static int comparison;
	static String string1;
	static String string2;

	static void getStrings() {
		Scanner input = new Scanner( System.in );

		System.out.print("Enter first string: ");
		string1 = input.next();
		System.out.print("Enter second string: ");
		string2 = input.next();

		return;
	}

	static int compareStrings() {
		return string1.compareTo(string2);
	}

	static void displayResults() {
		System.out.print("\nstring1 is ");
		if (comparison < 0) {
			System.out.print("less than ");
		}
		if (comparison == 0) {
			System.out.print("equal to ");
		}
		if (comparison > 0) {
			System.out.print("greater than ");
		}
		System.out.println("string2.");
	}

	public static void main(String[] args) {
		getStrings();
		comparison = compareStrings();
		displayResults();
	}
}
