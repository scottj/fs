/*
 *  Steven S. Johnson (0254221)
 *  COSC-1437-9467 (461331)
 *  Chapter 29 / Lab 6 / Page 1459
 */

import java.util.Calendar;

public class SJCh29Lab6P1459 {
	static Calendar dateTime = Calendar.getInstance();

	public static void main(String[] args) {
		System.out.printf("%s\n", "Happy Birthday");
		System.out.printf("%s\n", "Hello");		// or System.out.printf("%c\n", 'H');
		System.out.printf("%s\n", "This is a string");
		System.out.printf("\"%s\"\n", "Bon Voyage");
		System.out.printf("Today is %s\n", "Friday");
		System.out.printf("Enter your name: \n");
		System.out.printf("%f\n", 123.456);
		System.out.printf("%1$tH:%1$tM:%1$tS\n", dateTime);
	}

}
