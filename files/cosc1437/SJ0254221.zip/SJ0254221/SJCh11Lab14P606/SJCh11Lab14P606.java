/*
 *  Steven S. Johnson (0254221)
 *  COSC-1437-9467 (461331)
 *  Chapter 11 / Lab 14 / Page 606
 */

import javax.swing.JFrame;

public class SJCh11Lab14P606 {

	public static void main(String[] args) {
		EventsFrame eventFrame = new EventsFrame();
		eventFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		eventFrame.setSize(480, 320);
		eventFrame.setVisible(true);
	}

}
