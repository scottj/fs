import java.awt.AWTEvent;
import java.awt.FlowLayout;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;

public class EventsFrame extends JFrame {
	private JTextArea textArea;
	private JLabel label;
	private JComboBox comboBox;
	private String[] events = { "mouseClicked", "mouseEntered", "mouseExited",
			"mousePressed" };
	private int selectedEvent = 0;

	public EventsFrame() {
		super("Lab 11.14 - Events");
		setLayout(new FlowLayout());

		textArea = new JTextArea(15, 40);
		textArea.setAutoscrolls(true);
		textArea.setEditable(false);
		textArea.setLineWrap(true);
		add(textArea);
		label = new JLabel("Select an event to monitor: ");
		add(label);
		comboBox = new JComboBox(events);
		add(comboBox);

		// handle selection change in combo box
		comboBox.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent event) {
				if (event.getStateChange() == ItemEvent.SELECTED)
					selectedEvent = comboBox.getSelectedIndex();
			}
		});

		// add mouse event handlers
		MouseHandler handler = new MouseHandler();
		textArea.addMouseListener(handler);
		label.addMouseListener(handler);
		comboBox.addMouseListener(handler);
		addMouseListener(handler);

	}

	// MouseHandler class will hand off events to displayEvent()
	// when event is selected in the combo box
	private class MouseHandler extends MouseAdapter {
		public void mouseClicked(MouseEvent event) {
			if (selectedEvent == 0)
				displayEvent(event);
		}

		public void mouseEntered(MouseEvent event) {
			if (selectedEvent == 1)
				displayEvent(event);
		}

		public void mouseExited(MouseEvent event) {
			if (selectedEvent == 2)
				displayEvent(event);
		}

		public void mousePressed(MouseEvent event) {
			if (selectedEvent == 3)
				displayEvent(event);
		}
	}

	// display events in the textArea
	private void displayEvent(AWTEvent event) {
		textArea.setText(event.toString());
	}

}