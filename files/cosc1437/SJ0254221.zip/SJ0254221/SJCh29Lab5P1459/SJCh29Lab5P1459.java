/*
 *  Steven S. Johnson (0254221)
 *  COSC-1437-9467 (461331)
 *  Chapter 29 / Lab 5 / Page 1459
 */

public class SJCh29Lab5P1459 {

	public static void main(String[] args) {
		System.out.println("a) System.out.printf(\"%-10d\\n\", 10000, args);");
		System.out.printf("%-10d\n", 10000, args);

		System.out.println("\nb) System.out.printf(\"%c\\n\", \"This is a string\");");
		//System.out.printf("%c\n", "This is a string");
		System.out.println("This is incorrect and causes an IllegalFormatConversionException.\nTo format a string, %s should be used:");
		System.out.println("System.out.printf(\"%s\\n\", \"This is a string\");");
		System.out.printf("%s\n", "This is a string");

		System.out.println("\nc) System.out.printf(\"%8.3f\\n\", 1024.987654, args);");
		System.out.printf("%8.3f\n", 1024.987654, args);

		System.out.println("\nd) System.out.printf(\"%#o\\n%#X\\n\", 17, 17);");
		System.out.printf("%#o\n%#X\n", 17, 17);

		System.out.println("\ne) System.out.printf(\"% d\\n%+d\\n\", 1000000, 1000000);");
		System.out.printf("% d\n%+d\n", 1000000, 1000000);

		System.out.println("\nf) System.out.printf(\"%10.2e\\n\", 444.93738);");
		System.out.printf("%10.2e\n", 444.93738);

		System.out.println("\ng) System.out.printf(\"%d\\n\", 10.987);");
		//System.out.printf("%f\n", 10.987);
		System.out.println("This is incorrect and causes an IllegalFormatConversionException.\n%d should only be used for integers.  In this case, %f works:");
		System.out.println("System.out.printf(\"%f\\n\", 10.987);");
		System.out.printf("%f\n", 10.987);
	}

}
