/*
 *  Steven S. Johnson (0254221)
 *  COSC-1437-9467 (461331)
 *  Chapter 10 / Project 1 / Page 522
 */

public class SJCh10Prj1Pg522 {

	public static void main(String[] args) {
		// create four-element Payable array
		Payable payableObjects[] = new Payable[6];

		// populate array with objects that implement Payable
		payableObjects[0] = new Invoice("01234", "seat", 2, 375.00);
		payableObjects[1] = new Invoice("56789", "tire", 4, 79.95);
		payableObjects[2] = new SalariedEmployee("John", "Smith",
				"111-11-1111", 800.00);
		payableObjects[3] = new HourlyEmployee("Lisa", "Barnes", "888-88-8888",
				16.75, 40);
		payableObjects[4] = new CommissionEmployee("Jane", "Doe",
				"123-45-6789", 10000, 0.06);
		payableObjects[5] = new BasePlusCommissionEmployee("Karen", "Price",
				"432-56-1278", 5000, 0.04, 300);

		System.out
				.println("Invoices and Employees processed polymorphically:\n");

		// generically process each element in array payableObjects
		for (Payable currentPayable : payableObjects) {

			// add 10% to the BasePlusCommissionEmployees' Base Salaries
			if (currentPayable instanceof BasePlusCommissionEmployee) {
	            BasePlusCommissionEmployee employee =
	                ( BasePlusCommissionEmployee ) currentPayable;
	            employee.setBaseSalary(employee.getBaseSalary() * 1.1);
			}

			// output currentPayable and its appropriate payment amount
			System.out.printf("%s \n%s: $%,.2f\n\n", currentPayable.toString(),
					"payment due", currentPayable.getPaymentAmount());
		}
	}

}
